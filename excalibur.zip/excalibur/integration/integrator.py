import numpy as np
from multiprocessing import Pool, cpu_count
from functools import partial

###############################################################
#  VARIOUS INTEGRATORS
###############################################################

class RK4:
    def step(self, metric, state, dt, *_):
        k1 = metric.geodesic_equations(state)
        k2 = metric.geodesic_equations(state + 0.5 * dt * k1)
        k3 = metric.geodesic_equations(state + 0.5 * dt * k2)
        k4 = metric.geodesic_equations(state + dt * k3) 
        return state + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4), dt, True 

class Leapfrog4:
    """
    4th-order Forest–Ruth symplectic integrator (analytical coefficients).

    Assumes state = [x(4), u(4)], where the geodesic equations return:
        d/dλ [x, u] = [u, a(x,u)].

    This scheme is symplectic and time-reversible.
    It must be used with a FIXED timestep (not adaptive).
    """

    # Forest–Ruth analytical coefficients
    w0 = - 2.0**(1.0/3.0) / (2.0 - 2.0**(1.0/3.0))
    w1 = 1.0 / (2.0 - 2.0**(1.0/3.0))

    c1 = c4 = w1 / 2.0
    c2 = c3 = (w0 + w1) / 2.0

    d1 = d3 = w1
    d2 = w0

    def step(self, metric, state, dt, *_):
        """
        Perform one Forest–Ruth 4th order symplectic integration step.

        Parameters
        ----------
        metric : object
            Must provide geodesic_equations(state) -> [u, a]
        state : ndarray
            Size-8 vector [x, u]
        dt : float
            Fixed timestep
        *_ : ignored (keeps interface consistent)

        Returns
        -------
        new_state : ndarray
            Updated [x, u]
        dt : float
            Unchanged
        True : bool
            Always True (compatible with RK45 interface)
        """

        # unpack
        x = state[:4].copy()
        u = state[4:].copy()

        def accel(x, u):
            su = np.hstack([x, u])
            return metric.geodesic_equations(su)[4:]

        # Step 1
        x += self.c1 * dt * u
        u += self.d1 * dt * accel(x, u)
        # Step 2
        x += self.c2 * dt * u
        u += self.d2 * dt * accel(x, u)
        # Step 3
        x += self.c3 * dt * u
        u += self.d3 * dt * accel(x, u)
        # Step 4
        x += self.c4 * dt * u

        # pack
        new_state = np.hstack([x, u])
        return new_state, dt, True


class RK45Adaptive:
    """
    Vectorized adaptive RK45 integrator (Fehlberg)

    Notes:
    - metric.geodesic_equations(state) is still called 6 times per trial
      step (unavoidable), but all combination arithmetic is vectorized.
    - returns (new_state, new_dt, accepted)
    """

    def __init__(self):
        # Butcher tableau as full arrays for vectorized dot products
        # B is lower-triangular coefficients with zeros where unused
        self.B = np.zeros((6, 6), dtype=float)
        self.B[1, 0] = 1/4
        self.B[2, 0:2] = [3/32, 9/32]
        self.B[3, 0:3] = [1932/2197, -7200/2197, 7296/2197]
        self.B[4, 0:4] = [439/216, -8, 3680/513, -845/4104]
        self.B[5, 0:5] = [-8/27, 2, -3544/2565, 1859/4104, -11/40]

        # embedded formulas
        self.C5 = np.array([16/135, 0, 665/1287, 28561/56430, -9/50, 2/55])
        self.C4 = np.array([25/216, 0, 1408/2565, 2197/4104, -1/5, 0])

    def step(self, metric, state, dt, rtol, atol):
        # state is 1D array (size N)
        # We'll compute k[i] = f(state + dt * sum_j B[i,j] * k[j]) in sequence

        K = np.zeros((6, state.size), dtype=float)
        # k1
        K[0] = metric.geodesic_equations(state)

        # Compute k2..k6 — only 5 iterations at Python level
        for i in range(1, 6):
            # compute linear combination sum_j B[i,j] * K[j]
            # B[i, :i] dot K[:i] gives a vector of shape (state.size,)
            coeffs = self.B[i, :i]
            # use tensordot for efficiency
            incr = np.tensordot(coeffs, K[:i], axes=(0, 0))
            K[i] = metric.geodesic_equations(state + dt * incr)

        # Combine k's for 4th and 5th order estimates using vectorized dot
        y5 = state + dt * np.tensordot(self.C5, K, axes=(0, 0))
        y4 = state + dt * np.tensordot(self.C4, K, axes=(0, 0))

        # error estimate and acceptance
        err = np.abs(y5 - y4)
        tol = atol + rtol * np.maximum(np.abs(state), np.abs(y5))
        # handle zero tolerance entries
        tol = np.where(tol == 0.0, atol, tol)
        err_ratio = np.max(err / tol)

        if err_ratio <= 1.0:
            dt_new = dt * min(5.0, 0.9 * err_ratio ** -0.2 if err_ratio > 0 else 5.0)
            return y5, dt_new, True
        else:
            dt_new = dt * max(0.1, 0.9 * err_ratio ** -0.25)
            return state, dt_new, False


###############################################################
#  INTEGRATOR WITH MULTIPLE STOP CONDITIONS
###############################################################
class Integrator:

    STOP_MODES = {"steps", "redshift", "a", "chi"}
    INTEGRATORS = {"rk45": RK45Adaptive, "rk4": RK4, "leapfrog4": Leapfrog4}

    def __init__(
        self,
        metric,
        dt=1e-3,
        mode="sequential",
        integrator="rk45",
        rtol=1e-6,
        atol=1e-9,
        dt_min=1e-12,
        dt_max=0.1,
        n_workers=None,
        chunk_size=50,
    ):
        self.metric = metric
        self.dt = dt
        self.mode = mode
        self.rtol = rtol
        self.atol = atol
        self.dt_min = dt_min
        self.dt_max = dt_max
        self.chunk_size = chunk_size
        self.n_workers = n_workers if n_workers is not None else max(1, cpu_count() - 1)

        # Select the proper integrator based on user choice
        if integrator.lower() not in self.INTEGRATORS:
            raise ValueError(f"Integrator '{integrator}' not supported. Available: {list(self.INTEGRATORS.keys())}")

        # CRITICAL FIX: Actually use the requested integrator!
        integrator_class = self.INTEGRATORS[integrator.lower()]
        self.integrator = integrator_class()

    ###############################################################
    # STOPPING CONDITIONS
    ###############################################################
    def _should_stop(self, photon, stop_mode, stop_value):
        if stop_mode == "steps":
            return False  # handled externally
        elif stop_mode == "redshift":
            # assume photon.z increases when integrating backward/forward as in your project
            return photon.z >= stop_value
        elif stop_mode == "a":
            # factor of scale decreases when going backward in time: stop when a <= value
            return photon.a <= stop_value
        elif stop_mode == "chi":
            return photon.comoving_distance >= stop_value
        else:
            raise ValueError(f"Unknown stop mode {stop_mode}")

    ###############################################################
    # SEQUENTIAL SINGLE PHOTON (optimized loops)
    ###############################################################
    def integrate_single(self, photon, stop_mode="steps", stop_value=100):
        state = np.concatenate([photon.x, photon.u])
        dt = float(self.dt)
        steps = 0

        # Safety counter to avoid infinite loops if stop condition never met
        max_iter = int(1e4)  # OPTIMIZED: Reasonable limit
        it = 0

        # OPTIMIZATION: Pre-allocate history for better performance
        if not hasattr(photon, 'history'):
            photon.history = []
        
        # OPTIMIZATION: Cache metric physical quantities function to avoid lookups
        metric_quantities_func = self.metric.metric_physical_quantities

        while True:
            if it >= max_iter:
                break

            # external stop conditions
            if stop_mode == "steps" and steps >= stop_value:
                break
            if stop_mode != "steps" and self._should_stop(photon, stop_mode, stop_value):
                break

            # enforce dt limits - CRITICAL FIX: handle negative dt properly for backward tracing
            if dt < 0:
                # For backward tracing (negative dt), clip the absolute value then restore sign
                dt = -float(np.clip(abs(dt), self.dt_min, self.dt_max))
            else:
                # For forward tracing (positive dt)
                dt = float(np.clip(dt, self.dt_min, self.dt_max))
                
            # attempt step
            new_state, dt_new, accepted = self.integrator.step(
                self.metric, state, dt, self.rtol, self.atol
            )
            
            if accepted:
                state = new_state
                photon.x = state[:4]
                photon.u = state[4:]
                photon.state_quantities(metric_quantities_func)
                photon.record()
                
                steps += 1

            dt = dt_new
            it += 1
            
        # OPTIMIZATION: Ensure final state is always recorded
        photon.state_quantities(metric_quantities_func)
        photon.record()

        return photon

    ###############################################################
    # PARALLEL HELPERS
    ###############################################################
    def _worker_single(self, args):
        photon, stop_mode, stop_value = args
        try:
            return self.integrate_single(photon, stop_mode, stop_value), True
        except Exception:
            return photon, False

    def _worker_chunk(self, photons, stop_mode, stop_value):
        results = []
        for p in photons:
            try:
                integrated_photon = self.integrate_single(p, stop_mode, stop_value)
                results.append((integrated_photon, True))
            except Exception:
                results.append((p, False))
        return results

    ###############################################################
    # MAIN ENTRY POINT
    ###############################################################
    def integrate(self, photons, stop_mode="steps", stop_value=100, verbose=True):
        if stop_mode not in self.STOP_MODES:
            raise ValueError(f"stop_mode must be one of {self.STOP_MODES}")

        if self.mode == "sequential":
            for p in photons:
                self.integrate_single(p, stop_mode, stop_value)
            return len(photons)

        elif self.mode == "parallel":
            if verbose:
                print(f"Parallel integration with {self.n_workers} workers...")

            args = [(p, stop_mode, stop_value) for p in photons]
            with Pool(processes=self.n_workers) as pool:
                results = pool.map(self._worker_single, args)
            return sum(1 for _, ok in results if ok)

        elif self.mode == "chunked":
            # chunked mode: group photons to reduce multiprocessing overhead
            chunks = [photons[i:i+self.chunk_size] for i in range(0, len(photons), self.chunk_size)]
            if verbose:
                print(f"Chunked mode: {len(chunks)} chunks of size {self.chunk_size}")

            partial_func = partial(self._worker_chunk, stop_mode=stop_mode, stop_value=stop_value)
            with Pool(processes=self.n_workers) as pool:
                chunk_results = pool.map(partial_func, chunks)

            # Reconstruct photons list with integrated results
            success_count = 0
            photon_index = 0
            for chunk_result in chunk_results:
                for integrated_photon, success in chunk_result:
                    if success:
                        # Replace original photon with integrated version
                        photons.photons[photon_index] = integrated_photon
                        success_count += 1
                    photon_index += 1

            return success_count

        else:
            raise ValueError("Unknown mode. Use 'sequential', 'parallel', or 'chunked'.")
