# metrics/perturbed_flrw_metric.py
import numpy as np
from .base_metric import Metric
from excalibur.core.constants import *



class PerturbedFLRWMetric(Metric):
    """
    FLRW avec perturbations scalaires au premier ordre :
    ds² = a²(η)[-(1+2Ψ)dη² + (1-2Φ)δ_ij dx^i dx^j]
    """
    def __init__(self, cosmology, interpolator):
        self.cosmology = cosmology
        self.a_of_eta = cosmology.a_of_eta
        self.adot_of_eta = cosmology.adot_of_eta  # OPTIMIZATION: Direct access to fast adot
        self.interp = interpolator
        
        # CRITICAL OPTIMIZATION: Cache for expensive interpolations
        self._cache_x = None
        self._cache_phi_data = None
        self._cache_tolerance = 1e-12  # Spatial tolerance for cache hits

    def metric_tensor(self, x):
        eta, pos = x[0], x[1:]
        a = self.a_of_eta(eta)
        phi_dim, _, _ = self.interp.value_gradient_and_time_derivative(pos, "Phi", eta)
        phi = phi_dim / (c**2)  # Dimensionless
        psi = phi  # Supposons Ψ = Φ, aucun stress anisotrope

        g = np.zeros((4,4))
        g[0,0] = -a**2 * (1 + 2*psi) * c**2
        g[1,1] = a**2 * (1 - 2*phi)
        g[2,2] = a**2 * (1 - 2*phi)
        g[3,3] = a**2 * (1 - 2*phi)

        return g

    def christoffel(self, x):
        eta, pos = x[0], x[1:]
        a = self.a_of_eta(eta)
        adot = self.adot_of_eta(eta)  
        
        # CRITICAL OPTIMIZATION: Cache expensive interpolation calls
        # Check if we can reuse cached interpolation data
        cache_hit = (self._cache_x is not None and 
                    np.allclose(pos, self._cache_x[1:], atol=self._cache_tolerance) and
                    abs(eta - self._cache_x[0]) < self._cache_tolerance)
        
        if cache_hit:
            phi, grad_phi, phi_dot = self._cache_phi_data
        else:
            # Expensive interpolation - cache the result
            phi, grad_phi, phi_dot = self.interp.value_gradient_and_time_derivative(pos, "Phi", eta)
            self._cache_x = np.copy(x)
            self._cache_phi_data = (phi, grad_phi, phi_dot)
            
        psi, grad_psi, psi_dot = (phi, grad_phi, phi_dot) # Supposons Ψ = Φ 

        # PERFORMANCE OPTIMIZATION: Pre-calculate common terms
        c_inv = 1.0 / c
        c_inv2 = c_inv * c_inv
        c_inv4 = c_inv2 * c_inv2
        a_inv = 1.0 / a
        a_inv2 = a_inv * a_inv
        adot_over_a = adot * a_inv
        phi_plus_psi = phi + psi
        a_adot_c_inv2 = a * adot * c_inv2
        a2_phi_dot_c_inv4 = a * a * phi_dot * c_inv4

        Γ = np.zeros((4,4,4))

        # OPTIMIZED: Use pre-calculated terms
        Γ[0,0,0] = c_inv2 * psi_dot
        Γ[1,0,0] = grad_psi[0] * a_inv2
        Γ[2,0,0] = grad_psi[1] * a_inv2
        Γ[3,0,0] = grad_psi[2] * a_inv2
        Γ[1,1,1] = -c_inv2 * grad_phi[0]
        Γ[2,2,2] = -c_inv2 * grad_phi[1]
        Γ[3,3,3] = -c_inv2 * grad_phi[2]
        
        # Common term for diagonal metric components
        diag_term = a_adot_c_inv2 + 2 * a_adot_c_inv2 * c_inv2 * phi_plus_psi - a2_phi_dot_c_inv4
        Γ[0,1,1] = diag_term
        Γ[0,2,2] = diag_term  
        Γ[0,3,3] = diag_term
        
        Γ[0,0,1] = Γ[0,1,0] = grad_psi[0] * c_inv2
        Γ[0,0,2] = Γ[0,2,0] = grad_psi[1] * c_inv2
        Γ[0,0,3] = Γ[0,3,0] = grad_psi[2] * c_inv2
        
        time_mix_term = adot_over_a - phi_dot * c_inv2
        Γ[1,1,0] = Γ[1,0,1] = time_mix_term
        Γ[2,2,0] = Γ[2,0,2] = time_mix_term
        Γ[3,3,0] = Γ[3,0,3] = time_mix_term
        
        Γ[1,2,2] = Γ[1,3,3] = grad_phi[0] * c_inv2
        Γ[2,1,1] = Γ[2,3,3] = grad_phi[1] * c_inv2
        Γ[3,1,1] = Γ[3,2,2] = grad_phi[2] * c_inv2
        Γ[1,1,2] = Γ[1,2,1] = -grad_phi[1] * c_inv2
        Γ[1,1,3] = Γ[1,3,1] = -grad_phi[2] * c_inv2
        Γ[2,2,1] = Γ[2,1,2] = -grad_phi[0] * c_inv2
        Γ[2,2,3] = Γ[2,3,2] = -grad_phi[2] * c_inv2
        Γ[3,3,1] = Γ[3,1,3] = -grad_phi[0] * c_inv2
        Γ[3,3,2] = Γ[3,2,3] = -grad_phi[1] * c_inv2

        return Γ

    def geodesic_equations(self, state):
        x, u = state[:4], state[4:]
        Γ = self.christoffel(x)
        
        # PERFORMANCE OPTIMIZATION: Vectorized einsum instead of loop
        # This computes du[μ] = -Γ[μ,i,j] * u[i] * u[j] for all μ at once
        du = -np.einsum('mij,i,j->m', Γ, u, u)
        
        return np.concatenate([u, du])
    
    def metric_physical_quantities(self, state):
        eta, pos = state[0], state[1:4]
        a = self.a_of_eta(eta)
        phi, grad_phi, phi_dot = self.interp.value_gradient_and_time_derivative(pos, "Phi", eta)

        quantities = np.array([a, phi, *grad_phi, phi_dot])
        return quantities
        
